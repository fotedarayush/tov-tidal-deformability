EoS table GM1 Y5 for cold neutron star matter with hyperons in beta-equilibrium downloaded from http://compose.obspm.fr

References to the original work:
1. N. K. Glendenning and S. A. Moszkowski, Phys. Rev. Lett. 67, 2414 (1991)
2. M. Oertel, C. Providncia, F. Gulminelli, A. Raduta, arxiv:1412.4545.
3. F. Douchin, P. Haensel, Astronomy and Astrophysics 380, 151 (2001).

